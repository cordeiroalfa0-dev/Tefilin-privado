# Tefilin — código-base reconstruído

Este pacote foi recuperado do aplicativo portátil Tefilin v1.1.34, a partir do arquivo `resources/app.asar` publicado na release `v1.0.1` do repositório original.

## Conteúdo

- `electron/`: código legível recuperado do processo principal, preload, IPC, banco local, migrações e sincronização.
- `dist/`: build frontend compilado, incluindo HTML, CSS, JavaScript, imagens e service worker.
- `package.json`: manifesto de dependências e ponto de entrada Electron.

## Limitações

O frontend original foi publicado como bundle Vite compilado. Portanto, os arquivos-fonte React/TypeScript originais, nomes de variáveis descartados pelo empacotamento e mapas de origem não estão disponíveis neste artefato. O conteúdo em `dist/assets/` é o bundle executável recuperado e pode ser usado para análise e reconstrução incremental, mas não equivale ao código-fonte original não compilado.

As dependências `node_modules` e os binários do runtime Electron não foram incluídos neste ZIP para evitar um pacote excessivo e específico de plataforma. Execute `npm install` ou `pnpm install` usando o `package.json` para reinstalá-las.
