const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const SYNC_TABLES = [
  "igrejas",
  "membros",
  "dizimistas",
  "dizimos",
  "ofertas",
  "visitantes",
  "visitas_pastorais",
  "avisos",
  "patrimonio",
  "cartas_recomendacao",
  "cultos",
  "templates_whatsapp",
  "sync_health",
];

const now = () => new Date().toISOString();
const randomId = () => crypto.randomUUID();

function safeName(value) {
  return String(value || "sem-unidade").replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 80);
}

class SyncEngine {
  constructor(db, userData) {
    this.db = db;
    this.userData = userData;
    this.configFile = path.join(userData, "sync-config.json");
    this.state = this.loadConfig();
    this.timer = null;
    this.running = false;
    this.lastError = null;
    this.lastAction = null;
    this.lastActionAt = null;
    this.startAutoSync();
  }

  loadConfig() {
    try {
      const data = JSON.parse(fs.readFileSync(this.configFile, "utf8"));
      return {
        folder: data.folder || "",
        ministryId: data.ministryId || "tefilin-ministerio",
        branchId: data.branchId || "sede",
        branchName: data.branchName || "Sede",
        autoSync: data.autoSync === true,
        intervalSeconds: Math.max(60, Number(data.intervalSeconds || 300)),
        appliedPackages: Array.isArray(data.appliedPackages) ? data.appliedPackages.slice(-500) : [],
        lastPulledAt: data.lastPulledAt || null,
      };
    } catch (_) {
      return {
        folder: "",
        ministryId: "tefilin-ministerio",
        branchId: "sede",
        branchName: "Sede",
        autoSync: false,
        intervalSeconds: 300,
        appliedPackages: [],
        lastPulledAt: null,
      };
    }
  }

  saveConfig() {
    fs.mkdirSync(path.dirname(this.configFile), { recursive: true });
    fs.writeFileSync(this.configFile, JSON.stringify(this.state, null, 2));
  }

  configure(input = {}) {
    if (input.folder !== undefined) this.state.folder = String(input.folder || "").trim();
    if (input.ministryId !== undefined) this.state.ministryId = safeName(input.ministryId) || "tefilin-ministerio";
    if (input.branchId !== undefined) this.state.branchId = safeName(input.branchId) || "sede";
    if (input.branchName !== undefined) this.state.branchName = String(input.branchName || "Sede").trim() || "Sede";
    if (input.autoSync !== undefined) this.state.autoSync = Boolean(input.autoSync);
    if (input.intervalSeconds !== undefined) this.state.intervalSeconds = Math.max(60, Number(input.intervalSeconds || 300));
    this.saveConfig();
    this.startAutoSync();
    return this.status();
  }

  setFolder(folder) {
    return this.configure({ folder });
  }

  startAutoSync() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.state.autoSync && this.state.folder) {
      this.timer = setInterval(() => {
        this.syncNow().catch((e) => {
          this.lastError = String(e.message || e);
        });
      }, this.state.intervalSeconds * 1000);
      if (this.timer.unref) this.timer.unref();
    }
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  paths() {
    const base = path.join(this.state.folder, "Tefilin Sync", safeName(this.state.ministryId));
    return {
      base,
      outbox: path.join(base, "outbox", safeName(this.state.branchId)),
      inbox: path.join(base, "inbox", safeName(this.state.branchId)),
      sent: path.join(base, "sent", safeName(this.state.branchId)),
      processed: path.join(base, "processed", safeName(this.state.branchId)),
    };
  }

  ensurePaths() {
    if (!this.state.folder) throw new Error("Configure a pasta local sincronizada pelo Google Drive primeiro.");
    const p = this.paths();
    [p.base, p.outbox, p.inbox, p.sent, p.processed].forEach((dir) => fs.mkdirSync(dir, { recursive: true }));
    return p;
  }

  getCurrentBranchId() {
    return this.state.branchId;
  }

  collectRows() {
    const data = {};
    for (const table of SYNC_TABLES) {
      try {
        data[table] = this.db.prepare(`SELECT * FROM ${table}`).all();
      } catch (_) {
        data[table] = [];
      }
    }
    return data;
  }

  push() {
    if (this.running) throw new Error("Já existe uma sincronização em andamento.");
    this.running = true;
    this.lastError = null;
    try {
      const p = this.ensurePaths();
      
      // Se for filial, atualizar o registro de saúde no próprio banco antes de enviar
      if (this.state.branchId !== 'sede') {
        const healthId = `health-${this.state.branchId}`;
        this.db.prepare(`INSERT OR REPLACE INTO sync_health (id, igreja_id, nome_igreja, ultima_sincronizacao, versao_sistema, status) 
          VALUES (?, ?, ?, ?, ?, ?)`).run(
            healthId, this.state.branchId, this.state.branchName, now(), "1.1.30", "online"
          );
      }

      const packageId = `${Date.now()}-${randomId()}`;
      const payload = {
        format: "tefilin-sync-package",
        version: 1,
        packageId,
        ministryId: this.state.ministryId,
        branchId: this.state.branchId,
        branchName: this.state.branchName,
        createdAt: now(),
        source: "local-sqlite",
        data: this.collectRows(),
      };
      const tmp = path.join(p.outbox, `.${packageId}.json.tmp`);
      const target = path.join(p.outbox, `tefilin-${safeName(this.state.branchId)}-${packageId}.json`);
      fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), "utf8");
      fs.renameSync(tmp, target);
      this.lastAction = "push";
      this.lastActionAt = now();
      return { ok: true, packageId, file: target, rows: countRows(payload.data), status: this.status() };
    } catch (e) {
      this.lastError = String(e.message || e);
      throw e;
    } finally {
      this.running = false;
    }
  }

  pull() {
    if (this.running) throw new Error("Já existe uma sincronização em andamento.");
    this.running = true;
    this.lastError = null;
    const applied = [];
    const skipped = [];
    try {
      const p = this.ensurePaths();
      const outboxRoot = path.join(p.base, "outbox");
      const packageFiles = fs.existsSync(outboxRoot)
        ? fs.readdirSync(outboxRoot, { recursive: true })
          .filter((name) => String(name).endsWith(".json") && String(name).includes("tefilin-"))
          .map((name) => path.join(outboxRoot, String(name)))
          .filter((file) => fs.statSync(file).isFile())
          .sort()
        : [];

      for (const file of packageFiles) {
        let payload;
        try {
          payload = JSON.parse(fs.readFileSync(file, "utf8"));
        } catch (_) {
          skipped.push({ file, reason: "json-invalido-ou-incompleto" });
          continue;
        }
        if (payload.format !== "tefilin-sync-package" || payload.ministryId !== this.state.ministryId) {
          skipped.push({ file, reason: "pacote-de-outro-ministerio" });
          continue;
        }
        if (this.state.appliedPackages.includes(payload.packageId)) {
          skipped.push({ file, reason: "duplicado-ja-aplicado", packageId: payload.packageId });
          continue;
        }
        if (payload.branchId === this.state.branchId) {
          skipped.push({ file, reason: "pacote-da-propria-unidade", packageId: payload.packageId });
          continue;
        }

        const result = this.applyPackage(payload);
        this.state.appliedPackages.push(payload.packageId);
        this.state.appliedPackages = this.state.appliedPackages.slice(-500);
        this.state.lastPulledAt = now();
        const processedDir = path.join(p.base, "processed", safeName(payload.branchId));
        fs.mkdirSync(processedDir, { recursive: true });
        const processedPath = path.join(processedDir, path.basename(file));
        try { fs.renameSync(file, processedPath); } catch (_) {}
        applied.push({ packageId: payload.packageId, branchId: payload.branchId, branchName: payload.branchName, rows: result });
      }
      this.saveConfig();
      this.lastAction = "pull";
      this.lastActionAt = now();
      return { ok: true, applied, skipped, status: this.status() };
    } catch (e) {
      this.lastError = String(e.message || e);
      throw e;
    } finally {
      this.running = false;
    }
  }

  applyPackage(payload) {
    const tables = Object.keys(payload.data || {}).filter((table) => SYNC_TABLES.includes(table));
    let total = 0;
    this.db.exec("BEGIN");
    try {
      for (const table of tables) {
        const rows = Array.isArray(payload.data[table]) ? payload.data[table] : [];
        for (const row of rows) {
          const clean = { ...row };
          delete clean.rowid;
          if (!clean.id) continue;
          const columns = Object.keys(clean).filter((col) => /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(col));
          if (!columns.length) continue;
          const placeholders = columns.map(() => "?").join(",");
          const sql = `INSERT OR REPLACE INTO ${table} (${columns.join(",")}) VALUES (${placeholders})`;
          const values = columns.map((col) => normalizeValue(clean[col]));
          try {
            this.db.prepare(sql).run(...values);
            total += 1;
          } catch (_) {
            // Um registro incompatível não invalida o pacote inteiro; permanece documentado no log.
          }
        }
      }
      this.db.exec("COMMIT");
      return total;
    } catch (e) {
      try { this.db.exec("ROLLBACK"); } catch (_) {}
      throw e;
    }
  }

  syncNow() {
    const pushed = this.push();
    const pulled = this.pull();
    return { ok: true, pushed, pulled, status: this.status() };
  }

  status() {
    let filesPending = 0;
    let filesProcessed = 0;
    if (this.state.folder) {
      try {
        const p = this.paths();
        if (fs.existsSync(p.base)) {
          const outboxRoot = path.join(p.base, "outbox");
          const processedRoot = path.join(p.base, "processed");
          const pending = outboxRoot && fs.existsSync(outboxRoot) ? fs.readdirSync(outboxRoot, { recursive: true }).map(String) : [];
          const processed = processedRoot && fs.existsSync(processedRoot) ? fs.readdirSync(processedRoot, { recursive: true }).map(String) : [];
          filesPending = pending.filter((name) => name.endsWith(".json") && name.includes("tefilin-")).length;
          filesProcessed = processed.filter((name) => name.endsWith(".json") && name.includes("tefilin-")).length;
        }
      } catch (_) {}
    }
    return {
      configured: Boolean(this.state.folder),
      folder: this.state.folder,
      ministryId: this.state.ministryId,
      branchId: this.state.branchId,
      branchName: this.state.branchName,
      autoSync: this.state.autoSync,
      intervalSeconds: this.state.intervalSeconds,
      running: this.running,
      lastAction: this.lastAction,
      lastActionAt: this.lastActionAt,
      lastPulledAt: this.state.lastPulledAt,
      filesPending,
      filesProcessed,
      appliedPackages: this.state.appliedPackages.length,
      lastError: this.lastError,
      layout: this.state.folder ? "Tefilin Sync/<ministerio>/{outbox,inbox,processed}" : null,
    };
  }
}

function normalizeValue(value) {
  if (value === undefined) return null;
  if (value && typeof value === "object") return JSON.stringify(value);
  return value;
}

function countRows(data) {
  return Object.fromEntries(Object.entries(data || {}).map(([table, rows]) => [table, Array.isArray(rows) ? rows.length : 0]));
}

module.exports = { SyncEngine, SYNC_TABLES };
