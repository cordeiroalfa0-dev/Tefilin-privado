-- Tabela de Congregações
CREATE TABLE IF NOT EXISTS igrejas (
    id TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    tipo TEXT DEFAULT 'Congregação', -- 'Sede' ou 'Congregação'
    pastor_responsavel TEXT,
    endereco TEXT,
    cidade TEXT,
    estado TEXT,
    telefone TEXT,
    cnpj TEXT,
    data_fundacao TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Adicionar igreja_id em tabelas principais
-- SQLite não suporta adicionar múltiplas colunas ou FKs em tabelas existentes facilmente sem recriar, 
-- mas para fins de v1.1.26, adicionaremos as colunas. 
-- A integridade será mantida via aplicação nesta fase.

ALTER TABLE membros ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE dizimos ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE ofertas ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE patrimonio ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE visitantes ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE visitas_pastorais ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE avisos ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE cartas_recomendacao ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE cultos ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
ALTER TABLE dizimistas ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
