-- Adicionar igreja_id na tabela profiles para associar o usuário à sua filial
ALTER TABLE profiles ADD COLUMN igreja_id TEXT REFERENCES igrejas(id);
