CREATE TABLE IF NOT EXISTS cartas_recomendacao (
    id TEXT PRIMARY KEY,
    numero VARCHAR(20) NOT NULL,
    membro_id TEXT NOT NULL,
    igreja_destino VARCHAR(200),
    cidade_destino VARCHAR(150),
    pastor_destino VARCHAR(150),
    tipo VARCHAR(50) DEFAULT 'Recomendação',
    motivo VARCHAR(100),
    observacoes TEXT,
    data_emissao DATE NOT NULL,
    data_validade DATE,
    emitida_por TEXT,
    status VARCHAR(20) DEFAULT 'Ativa',
    qr_code TEXT,
    pdf_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (membro_id) REFERENCES membros(id)
);

CREATE INDEX IF NOT EXISTS idx_cartas_membro ON cartas_recomendacao(membro_id);
CREATE INDEX IF NOT EXISTS idx_cartas_numero ON cartas_recomendacao(numero);
