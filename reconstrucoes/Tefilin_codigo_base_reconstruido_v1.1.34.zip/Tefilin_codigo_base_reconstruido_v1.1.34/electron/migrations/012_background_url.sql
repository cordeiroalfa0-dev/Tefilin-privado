ALTER TABLE configuracoes ADD COLUMN background_url TEXT;
