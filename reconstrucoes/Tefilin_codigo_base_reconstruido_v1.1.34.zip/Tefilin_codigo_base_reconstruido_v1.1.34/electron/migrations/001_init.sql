-- Tefilin schema (SQLite)
-- UUID helper: usar lower(hex(randomblob(16)))

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  raw_user_meta_data TEXT DEFAULT '{}',
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE profiles (
  id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  email TEXT,
  avatar_url TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE user_roles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('admin','moderator','user')),
  UNIQUE(user_id, role)
);

CREATE TABLE user_permissions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  dashboard_route TEXT NOT NULL,
  can_access INTEGER DEFAULT 1,
  UNIQUE(user_id, dashboard_route)
);

CREATE TABLE dashboards (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT DEFAULT 'LayoutDashboard',
  route TEXT NOT NULL UNIQUE,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE configuracoes (
  id TEXT PRIMARY KEY,
  nome_sistema TEXT NOT NULL DEFAULT 'Tefilin',
  nome_igreja TEXT,
  logo_url TEXT,
  endereco TEXT,
  contato TEXT,
  email TEXT,
  cabecalho TEXT,
  rodape TEXT,
  rodape_login TEXT,
  versiculo TEXT,
  tema TEXT DEFAULT 'light',
  cor_primaria TEXT,
  cor_fundo TEXT,
  cor_cards TEXT,
  cor_sidebar TEXT,
  cor_texto TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE visitantes (
  id TEXT PRIMARY KEY,
  nome_completo TEXT NOT NULL,
  telefone TEXT,
  email TEXT,
  endereco TEXT,
  data_nascimento TEXT,
  observacoes TEXT,
  como_conheceu TEXT,
  primeira_visita TEXT,
  status TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE visitas_pastorais (
  id TEXT PRIMARY KEY,
  visitante_id TEXT REFERENCES visitantes(id) ON DELETE SET NULL,
  data_visita TEXT,
  pastor_responsavel TEXT,
  observacoes TEXT,
  status TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE cultos (
  id TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  dia_semana TEXT,
  horario TEXT,
  descricao TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE dizimistas (
  id TEXT PRIMARY KEY,
  nome_completo TEXT NOT NULL,
  telefone TEXT,
  email TEXT,
  endereco TEXT,
  data_nascimento TEXT,
  observacoes TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE dizimos (
  id TEXT PRIMARY KEY,
  dizimista_id TEXT REFERENCES dizimistas(id) ON DELETE SET NULL,
  culto_id TEXT REFERENCES cultos(id) ON DELETE SET NULL,
  valor REAL NOT NULL DEFAULT 0,
  data TEXT,
  forma_pagamento TEXT,
  observacoes TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE ofertas (
  id TEXT PRIMARY KEY,
  culto_id TEXT REFERENCES cultos(id) ON DELETE SET NULL,
  valor REAL NOT NULL DEFAULT 0,
  data TEXT,
  tipo TEXT,
  observacoes TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE avisos (
  id TEXT PRIMARY KEY,
  texto TEXT NOT NULL,
  imagens TEXT DEFAULT '[]',
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE templates_whatsapp (
  id TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  mensagem TEXT NOT NULL,
  categoria TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE mensagens_whatsapp (
  id TEXT PRIMARY KEY,
  visitante_id TEXT REFERENCES visitantes(id) ON DELETE SET NULL,
  template_id TEXT REFERENCES templates_whatsapp(id) ON DELETE SET NULL,
  mensagem TEXT,
  telefone TEXT,
  enviado_em TEXT DEFAULT (datetime('now')),
  created_by TEXT
);

CREATE TABLE backups (
  id TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  arquivo_url TEXT,
  tamanho INTEGER,
  created_at TEXT DEFAULT (datetime('now')),
  created_by TEXT
);

-- seeds
INSERT INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Overview', 'Visão geral do sistema', 'LayoutDashboard', '/dashboard'),
  (lower(hex(randomblob(16))), 'Analytics', 'Análises e relatórios', 'BarChart3', '/analytics'),
  (lower(hex(randomblob(16))), 'Users', 'Gerenciamento de usuários', 'Users', '/users'),
  (lower(hex(randomblob(16))), 'Settings', 'Configurações', 'Settings', '/settings');

INSERT INTO configuracoes (id, nome_sistema, nome_igreja) VALUES
  ('1', 'Tefilin Pro', 'Igreja Evangélica Manassés');