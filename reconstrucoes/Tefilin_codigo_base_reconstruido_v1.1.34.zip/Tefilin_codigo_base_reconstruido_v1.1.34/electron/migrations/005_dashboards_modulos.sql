-- Garante que todos os módulos do sistema possam ter permissão atribuída
CREATE UNIQUE INDEX IF NOT EXISTS idx_dashboards_route ON dashboards(route);
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Recepção', 'Cadastro de visitantes', 'UserPlus', '/recepcao');
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Pastoral', 'Visitas e acompanhamento', 'HeartHandshake', '/pastoral');
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Dizimistas', 'Gestão de dízimos', 'Wallet', '/dizimistas');
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Relatórios', 'Relatórios consolidados', 'FileText', '/relatorios');
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Aniversariantes', 'Aniversários e lembretes', 'Cake', '/aniversariantes');
INSERT OR IGNORE INTO dashboards (id, name, description, icon, route) VALUES
  (lower(hex(randomblob(16))), 'Administração', 'Painel administrativo', 'Shield', '/admin');
