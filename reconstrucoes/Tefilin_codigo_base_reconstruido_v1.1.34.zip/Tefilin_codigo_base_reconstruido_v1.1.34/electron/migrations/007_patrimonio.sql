CREATE TABLE IF NOT EXISTS patrimonio (
    id TEXT PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    quantidade INTEGER NOT NULL DEFAULT 1,
    valor_estimado REAL DEFAULT 0,
    estado VARCHAR(50),
    observacoes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
