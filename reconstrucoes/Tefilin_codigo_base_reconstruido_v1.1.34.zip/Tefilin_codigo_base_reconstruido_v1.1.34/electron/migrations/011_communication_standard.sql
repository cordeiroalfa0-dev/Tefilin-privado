-- Adicionar flag de aviso global
ALTER TABLE avisos ADD COLUMN eh_global INTEGER DEFAULT 0;

-- Adicionar histórico de transferências aos membros
ALTER TABLE membros ADD COLUMN historico_transferencias TEXT DEFAULT '[]';

-- Tabela para monitoramento de saúde das filiais (Sede)
CREATE TABLE IF NOT EXISTS sync_health (
    id TEXT PRIMARY KEY,
    igreja_id TEXT REFERENCES igrejas(id),
    nome_igreja TEXT,
    ultima_sincronizacao TEXT,
    versao_sistema TEXT,
    pacotes_enviados INTEGER DEFAULT 0,
    status TEXT -- 'online', 'atrasado', 'offline'
);
