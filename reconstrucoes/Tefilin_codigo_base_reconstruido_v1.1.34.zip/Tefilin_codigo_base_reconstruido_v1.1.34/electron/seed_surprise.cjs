const crypto = require("crypto");
const bcrypt = require("bcryptjs");

const uuid = () => crypto.randomUUID();

function seedSurprise(db) {
  console.log(">>> INICIANDO SEED SURPRESA: CATEDRAL DA ESPERANÇA INTERNACIONAL <<<");

  // Limpeza de tabelas principais
  const tables = [
    "mensagens_whatsapp", "visitas_pastorais", "dizimos", "ofertas", "avisos",
    "dizimistas", "visitantes", "templates_whatsapp", "cultos", "patrimonio",
    "cartas_recomendacao", "membros", "user_roles", "profiles", "sessions", "users", "configuracoes", "igrejas", "sync_health"
  ];
  db.exec("PRAGMA foreign_keys = OFF");
  tables.forEach(t => {
    try { db.exec(`DELETE FROM ${t}`); } catch(e) {}
  });
  db.exec("PRAGMA foreign_keys = ON");

  // 1. Criar Sede Mundial
  const sedeId = uuid();
  db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    sedeId, 'Catedral da Esperança Internacional - Sede Mundial', 'Sede', 'Apóstolo Gabriel Arcanjo', 'Avenida Paulista, 1000', 'São Paulo', 'SP'
  );

  // 2. Criar 10 Filiais de Elite
  const filiais = [
    { nome: 'Catedral da Esperança - New York (USA)', cidade: 'New York', pastor: 'Pr. Michael Smith' },
    { nome: 'Catedral da Esperança - Lisboa (PT)', cidade: 'Lisboa', pastor: 'Pr. Manuel Pereira' },
    { nome: 'Catedral da Esperança - Rio de Janeiro (RJ)', cidade: 'Rio de Janeiro', pastor: 'Pr. Ricardo Fontes' },
    { nome: 'Catedral da Esperança - Brasília (DF)', cidade: 'Brasília', pastor: 'Pr. Paulo Henrique' },
    { nome: 'Catedral da Esperança - Dubai (UAE)', cidade: 'Dubai', pastor: 'Pr. David Al-Maktoum' },
    { nome: 'Catedral da Esperança - Londres (UK)', cidade: 'Londres', pastor: 'Pr. Arthur Pendragon' },
    { nome: 'Catedral da Esperança - Tóquio (JP)', cidade: 'Tóquio', pastor: 'Pr. Kenji Tanaka' },
    { nome: 'Catedral da Esperança - Paris (FR)', cidade: 'Paris', pastor: 'Pr. Jean-Luc Godard' },
    { nome: 'Catedral da Esperança - Buenos Aires (AR)', cidade: 'Buenos Aires', pastor: 'Pr. Diego Maradona' },
    { nome: 'Catedral da Esperança - Roma (IT)', cidade: 'Roma', pastor: 'Pr. Francesco Rossi' }
  ];

  const filialIds = [];
  filiais.forEach(f => {
    const fId = uuid();
    filialIds.push(fId);
    db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      fId, f.nome, 'Congregação', f.pastor, `Elite District, 500 - ${f.cidade}`, f.cidade, 'INT'
    );
  });

  const todasIgrejas = [sedeId, ...filialIds];

  // 3. Branding de Elite
  db.prepare("INSERT INTO configuracoes (id, nome_sistema, nome_igreja, versiculo, endereco, cor_primaria, cor_sidebar, cor_cards, cor_fundo, cor_texto, logo_url, background_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(
    'default',
    'Tefilin Pro Elite',
    'Catedral da Esperança Internacional',
    'Porque eu, o Senhor teu Deus, te tomo pela tua mão direita; e te digo: Não temas, que eu te ajudo. (Isaías 41:13)',
    'Avenida Paulista, 1000 - Bela Vista, São Paulo/SP',
    '#D4AF37', // Dourado
    '#0F2A40', // Azul Marinho Profundo
    '#FFFFFF',
    '#F1F5F9',
    '#1E293B',
    './logo_catedral.png',
    './bg_catedral.jpg'
  );

  // 4. Usuários
  const adminId = uuid();
  const hash = bcrypt.hashSync("admin123", 10);
  db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
    adminId, "apostolo@catedral.com", hash, JSON.stringify({ username: "Apóstolo Gabriel" })
  );
  db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(adminId, "Apóstolo Gabriel", "apostolo@catedral.com", sedeId);
  db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), adminId, "admin");

  filialIds.forEach((fId, index) => {
    const uId = uuid();
    const email = `pastor${index + 1}@catedral.com`;
    db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
      uId, email, hash, JSON.stringify({ username: filiais[index].pastor })
    );
    db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(uId, filiais[index].pastor, email, fId);
    db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), uId, "admin");
  });

  // 5. Dados Massivos
  const prenomes = ["Alexandre", "Bárbara", "Caio", "Daniele", "Eduardo", "Fabiana", "Guilherme", "Helena", "Ítalo", "Jéssica", "Kevin", "Larissa", "Murilo", "Natália", "Otávio", "Priscila", "Quirino", "Renata", "Samuel", "Tatiana"];
  const sobrenomes = ["Bittencourt", "Cavalcante", "Drummond", "Espinosa", "Figueiredo", "Guimarães", "Holanda", "Igrejas", "Junqueira", "Kohl", "Lacerda", "Montenegro", "Nogueira", "Ornellas", "Pacheco", "Queiroz", "Rocha", "Siqueira", "Teixeira", "Uchoa"];

  function gerarNome() {
    return prenomes[Math.floor(Math.random() * prenomes.length)] + " " + 
           sobrenomes[Math.floor(Math.random() * sobrenomes.length)] + " " + 
           sobrenomes[Math.floor(Math.random() * sobrenomes.length)];
  }

  // Membros
  const stmtMembro = db.prepare("INSERT INTO membros (id, nome_completo, status, cargo, congregacao, eh_dizimista, igreja_id, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  for (let i = 0; i < 300; i++) {
    const id = uuid();
    const igrejaId = todasIgrejas[i % todasIgrejas.length];
    const mes = (Math.floor(Math.random() * 12) + 1).toString().padStart(2, '0');
    stmtMembro.run(id, gerarNome(), 'ativo', i < 15 ? 'Pastor' : (i < 40 ? 'Obreiro' : 'Membro'), 'Santuário Principal', 1, igrejaId, `1980-${mes}-15`);
  }

  // Finanças
  const stmtDizimista = db.prepare("INSERT INTO dizimistas (id, nome_completo, telefone, igreja_id) VALUES (?, ?, ?, ?)");
  const stmtDizimo = db.prepare("INSERT INTO dizimos (id, dizimista_id, valor, data, forma_pagamento, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  const stmtOferta = db.prepare("INSERT INTO ofertas (id, valor, data, tipo, igreja_id) VALUES (?, ?, ?, ?, ?)");

  const membros = db.prepare("SELECT id, nome_completo, igreja_id FROM membros").all();
  membros.forEach((m, i) => {
    const dId = uuid();
    stmtDizimista.run(dId, m.nome_completo, '(11) 9' + Math.floor(10000000 + Math.random() * 90000000), m.igreja_id);
    stmtDizimo.run(uuid(), dId, 500 + Math.random() * 2000, '2026-08-10', 'PIX', m.igreja_id);
    stmtOferta.run(uuid(), 200 + Math.random() * 1000, '2026-08-15', 'Oferta Missionária', m.igreja_id);
  });

  // Patrimonio
  const stmtPatrimonio = db.prepare("INSERT INTO patrimonio (id, nome, quantidade, valor_estimado, estado, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  const itens = ["Sistema de Som Line Array", "Projetor 4K Laser", "Piano de Cauda", "Cadeiras Estofadas Elite", "Ar Condicionado Central"];
  todasIgrejas.forEach(igId => {
    itens.forEach(item => {
      stmtPatrimonio.run(uuid(), item, 1, 5000 + Math.random() * 50000, 'excelente', igId);
    });
  });

  // Avisos
  const stmtAviso = db.prepare("INSERT INTO avisos (id, texto, eh_global, igreja_id) VALUES (?, ?, ?, ?)");
  stmtAviso.run(uuid(), "GRANDE CONGRESSO INTERNACIONAL - De 15 a 20 de Setembro na Sede Mundial.", 1, sedeId);
  stmtAviso.run(uuid(), "NOVA CAMPANHA DE MISSÕES - Alcançando as nações com a Esperança.", 1, sedeId);

  console.log(">>> SEED SURPRESA CONCLUÍDO COM SUCESSO! <<<");
}

module.exports = { seedSurprise };
