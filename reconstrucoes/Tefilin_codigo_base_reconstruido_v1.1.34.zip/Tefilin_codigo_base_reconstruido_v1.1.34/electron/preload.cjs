const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  db: {
    query: (op) => ipcRenderer.invoke("db:query", op),
  },
  auth: {
    signUp: (p) => ipcRenderer.invoke("auth:signUp", p),
    createUser: (p) => ipcRenderer.invoke("auth:createUser", p),
    deleteUser: (userId) => ipcRenderer.invoke("auth:deleteUser", userId),
    signIn: (p) => ipcRenderer.invoke("auth:signIn", p),
    signOut: (t) => ipcRenderer.invoke("auth:signOut", t),
    getUser: (t) => ipcRenderer.invoke("auth:getUser", t),
  },
  storage: {
    upload: (p) => ipcRenderer.invoke("storage:upload", p),
    remove: (p) => ipcRenderer.invoke("storage:remove", p),
    download: (p) => ipcRenderer.invoke("storage:download", p),
    publicUrl: (p) => ipcRenderer.invoke("storage:publicUrl", p),
    list: (p) => ipcRenderer.invoke("storage:list", p),
  },
  dbFile: {
    export: () => ipcRenderer.invoke("dbfile:export"),
    import: () => ipcRenderer.invoke("dbfile:import"),
  },
  sync: {
    chooseFolder: () => ipcRenderer.invoke("sync:chooseFolder"),
    status: () => ipcRenderer.invoke("sync:status"),
    configure: (p) => ipcRenderer.invoke("sync:configure", p),
    push: () => ipcRenderer.invoke("sync:push"),
    pull: () => ipcRenderer.invoke("sync:pull"),
    now: () => ipcRenderer.invoke("sync:now"),
    stop: () => ipcRenderer.invoke("sync:stop"),
  },
  isElectron: true,
});