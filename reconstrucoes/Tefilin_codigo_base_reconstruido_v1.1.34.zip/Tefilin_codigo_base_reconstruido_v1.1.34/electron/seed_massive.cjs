const bcrypt = require("bcryptjs");
const crypto = require("crypto");

const uuid = () => crypto.randomUUID();

function seedMassive(db) {
  console.log(">>> INICIANDO TRANSFORMAÇÃO MULTI-IGREJA v1.1.26 <<<");

  // 1. LIMPEZA TOTAL (FORÇADA)
  const tables = [
    "mensagens_whatsapp", "visitas_pastorais", "dizimos", "ofertas", "avisos",
    "dizimistas", "visitantes", "templates_whatsapp", "cultos", "patrimonio",
    "cartas_recomendacao", "membros", "user_roles", "profiles", "sessions", "users", "configuracoes", "igrejas"
  ];
  db.exec("PRAGMA foreign_keys = OFF");
  tables.forEach(t => {
    try { db.exec(`DELETE FROM ${t}`); } catch(e) {}
  });
  db.exec("PRAGMA foreign_keys = ON");

  // 2. CADASTRAR IGREJAS (SEDE E FILIAIS)
  const sedeId = uuid();
  const filialNorteId = uuid();
  const filialSulId = uuid();

  db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    sedeId, 'Sede Mundial Avivamento', 'Sede', 'Bispo Emerson', 'Av. das Nações Unidas, 888', 'Curitiba', 'PR'
  );
  db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    filialNorteId, 'Avivamento Profético - Norte', 'Congregação', 'Pr. André', 'Rua das Flores, 100', 'Curitiba', 'PR'
  );
  db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    filialSulId, 'Avivamento Profético - Sul', 'Congregação', 'Pr. Ricardo', 'Av. Central, 500', 'São José dos Pinhais', 'PR'
  );

  const igrejasIds = [sedeId, filialNorteId, filialSulId];

  // 3. BRANDING V1.1.26 (VIOLETA & NAVY)
  db.prepare("INSERT INTO configuracoes (id, nome_sistema, nome_igreja, versiculo, endereco, cor_primaria, cor_sidebar, cor_cards, cor_fundo, cor_texto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(
    'default',
    'Tefilin Pro',
    'Ministério Avivamento Profético',
    'Pois eu sei os planos que tenho para vocês, diz o Senhor, planos de prosperidade e não de mal. (Jeremias 29:11)',
    'Av. das Nações Unidas, 888 - Centro, Curitiba/PR',
    '#7C3AED', // Violeta Imperial
    '#0F172A', // Navy Profundo
    '#FFFFFF', // Branco
    '#F8FAFC', // Cinza Gelo
    '#1E293B'  // Texto Slate
  );

  // 4. NOVOS USUÁRIOS (SEDE E FILIAL)
  const adminId = uuid();
  const hash = bcrypt.hashSync("admin123", 10);
  db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
    adminId, "bispo@avivamento.com", hash, JSON.stringify({ username: "Bispo Emerson" })
  );
  db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(adminId, "Bispo Emerson", "bispo@avivamento.com", sedeId);
  db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), adminId, "admin");

  const filialUserId = uuid();
  db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
    filialUserId, "pastor@filial.com", hash, JSON.stringify({ username: "Pr. Filial" })
  );
  db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(filialUserId, "Pr. Filial", "pastor@filial.com", filialNorteId);
  db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), filialUserId, "admin");

  // 5. GERADORES DE DADOS (80 registros distribuídos)
  const nomes = ["Oliveira", "Souza", "Pereira", "Costa", "Carvalho", "Almeida", "Ferreira", "Ribeiro", "Mendes", "Rocha", "Gomes", "Alves", "Martins", "Teixeira", "Barbosa"];
  const prenomes = ["José", "Maria", "João", "Ana", "Antônio", "Francisca", "Carlos", "Adriana", "Paulo", "Márcia", "Lucas", "Beatriz", "Gabriel", "Juliana", "Marcos", "Fernanda", "Rafael", "Camila", "Bruno", "Patrícia", "Daniel", "Letícia", "Rodrigo", "Vanessa", "Tiago", "Tatiane"];

  function gerarNome() {
    return prenomes[Math.floor(Math.random() * prenomes.length)] + " " + 
           nomes[Math.floor(Math.random() * nomes.length)] + " " + 
           nomes[Math.floor(Math.random() * nomes.length)];
  }

  // MEMBROS (80)
  const membrosIds = [];
  const stmtMembro = db.prepare("INSERT INTO membros (id, nome_completo, status, cargo, congregacao, eh_dizimista, igreja_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
  for(let i=0; i<80; i++) {
    const id = uuid();
    membrosIds.push(id);
    const igrejaId = igrejasIds[i % 3];
    const cargo = i === 0 ? 'Bispo Presidente' : (i < 8 ? 'Pastor' : (i < 25 ? 'Obreiro' : 'Membro'));
    stmtMembro.run(id, gerarNome(), 'ativo', cargo, i % 5 === 0 ? 'Sede Mundial' : 'Distrito Leste', i % 2 === 0 ? 1 : 0, igrejaId);
  }

  // DIZIMISTAS E DÍZIMOS (80)
  const stmtDizimista = db.prepare("INSERT INTO dizimistas (id, nome_completo, telefone, igreja_id) VALUES (?, ?, ?, ?)");
  const stmtDizimo = db.prepare("INSERT INTO dizimos (id, dizimista_id, valor, data, forma_pagamento, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  membrosIds.forEach((mid, i) => {
    const dId = uuid();
    const membro = db.prepare("SELECT nome_completo, igreja_id FROM membros WHERE id = ?").get(mid);
    stmtDizimista.run(dId, membro.nome_completo, `(41) 9${Math.floor(Math.random()*90000000 + 10000000)}`, membro.igreja_id);
    db.prepare("UPDATE membros SET dizimista_id = ? WHERE id = ?").run(dId, mid);
    stmtDizimo.run(uuid(), dId, 200 + Math.random()*2000, '2026-08-' + (Math.floor(Math.random()*20)+1).toString().padStart(2, '0'), i % 3 === 0 ? 'PIX' : 'Cartão', membro.igreja_id);
  });

  // OFERTAS (80)
  const stmtOferta = db.prepare("INSERT INTO ofertas (id, valor, data, tipo, igreja_id) VALUES (?, ?, ?, ?, ?)");
  for(let i=0; i<80; i++) {
    stmtOferta.run(uuid(), 150 + Math.random()*1000, '2026-08-' + (Math.floor(Math.random()*20)+1).toString().padStart(2, '0'), 'Oferta Geral', igrejasIds[i % 3]);
  }

  // VISITANTES E VISITAS (80)
  const stmtVisitante = db.prepare("INSERT INTO visitantes (id, nome_completo, primeira_visita, status, igreja_id) VALUES (?, ?, ?, ?, ?)");
  const stmtVisita = db.prepare("INSERT INTO visitas_pastorais (id, visitante_id, data_visita, pastor_responsavel, status, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  for(let i=0; i<80; i++) {
    const vId = uuid();
    const igrejaId = igrejasIds[i % 3];
    stmtVisitante.run(vId, gerarNome(), '2026-08-01', 'Novo', igrejaId);
    stmtVisita.run(uuid(), vId, '2026-08-30', 'Bispo Emerson', 'Agendada', igrejaId);
  }

  // PATRIMÔNIO (80)
  const itensBase = ["Cadeira Luxo", "Microfone Shure", "Console de Mixagem", "Protetor de Surto", "Púlpito de Madeira", "Piano Digital", "Projetor 4K", "Monitor de Palco", "Ar Condicionado", "Painel de LED"];
  const stmtPatrimonio = db.prepare("INSERT INTO patrimonio (id, nome, quantidade, valor_estimado, estado, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  for(let i=0; i<80; i++) {
    stmtPatrimonio.run(uuid(), itensBase[i % itensBase.length] + " XP-" + (i+1), Math.floor(Math.random()*10)+1, 500 + Math.random()*10000, 'Novo', igrejasIds[i % 3]);
  }

  // AVISOS TV (80)
  const stmtAviso = db.prepare("INSERT INTO avisos (id, texto, igreja_id) VALUES (?, ?, ?)");
  for(let i=1; i<=80; i++) {
    stmtAviso.run(uuid(), `Aviso Profético #${i}: "Prepare-se para o grande mover de Deus neste domingo!"`, igrejasIds[i % 3]);
  }

  console.log(">>> TRANSFORMAÇÃO MULTI-IGREJA v1.1.26 CONCLUÍDA! <<<");
}

module.exports = { seedMassive };
