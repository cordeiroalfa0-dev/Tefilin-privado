const { app, BrowserWindow, ipcMain, protocol, dialog } = require("electron");
const path = require("path");
const fs = require("fs");

// Crash log — arquivo dentro de %APPDATA%\Tefilin\startup.log
function writeStartupLog(msg) {
  try {
    const dir = app.getPath("userData");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, "startup.log"),
      `[${new Date().toISOString()}] ${msg}\n`);
  } catch (_) {}
}

process.on("uncaughtException", (e) => {
  writeStartupLog("uncaughtException: " + (e && e.stack || e));
});
process.on("unhandledRejection", (e) => {
  writeStartupLog("unhandledRejection: " + (e && e.stack || e));
});

let initDb, registerIpc, seedDefaults;
try {
  ({ initDb } = require("./db.cjs"));
  ({ registerIpc, seedDefaults } = require("./ipc.cjs"));
} catch (e) {
  writeStartupLog("require failed: " + (e && e.stack || e));
  throw e;
}
const { checkpoint } = require("./db.cjs");

const isDev = false; // forçar build local nos testes
let mainWindow = null;
let dbRef = null;
let syncEngineRef = null;

// --- Estado da janela (tamanho/posição/maximizada) persistido em disco ---
function stateFile() {
  return path.join(app.getPath("userData"), "window-state.json");
}
function loadWindowState() {
  try {
    return JSON.parse(fs.readFileSync(stateFile(), "utf8"));
  } catch (_) {
    return { width: 1280, height: 800 };
  }
}
function saveWindowState(win) {
  try {
    if (!win || win.isDestroyed()) return;
    const b = win.getNormalBounds ? win.getNormalBounds() : win.getBounds();
    fs.writeFileSync(
      stateFile(),
      JSON.stringify({ ...b, maximized: win.isMaximized() })
    );
  } catch (_) {}
}

function ensureDirs() {
  const userData = app.getPath("userData");
  for (const sub of ["", "uploads", "backups"]) {
    const p = path.join(userData, sub);
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
  }
  return userData;
}

function rotateBackup(db, userData) {
  try {
    checkpoint(db); // garante que o WAL esteja aplicado antes de copiar
    const today = new Date().toISOString().slice(0, 10);
    const dst = path.join(userData, "backups", `tefilin-${today}.db`);
    if (!fs.existsSync(dst)) {
      fs.copyFileSync(path.join(userData, "tefilin.db"), dst);
    }
    // mantém últimos 7
    const files = fs.readdirSync(path.join(userData, "backups"))
      .filter((f) => f.endsWith(".db"))
      .sort();
    while (files.length > 7) {
      fs.unlinkSync(path.join(userData, "backups", files.shift()));
    }
  } catch (e) {
    console.error("backup failed", e);
  }
}

function createWindow() {
  const state = loadWindowState();
  const win = new BrowserWindow({
    width: state.width || 1280,
    height: state.height || 800,
    x: state.x,
    y: state.y,
    minWidth: 900,
    minHeight: 600,
    show: false,
    backgroundColor: "#0b1220",
    autoHideMenuBar: true,
    icon: path.join(__dirname, "..", "build", "icon.ico"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (isDev) {
    win.loadURL("http://localhost:8080");
  } else {
    const indexPath = path.join(__dirname, "..", "dist", "index.html");
    writeStartupLog("loadFile " + indexPath + " exists=" + fs.existsSync(indexPath));
    win.loadFile(indexPath).catch((e) => writeStartupLog("loadFile err: " + e));
  }
  win.webContents.on("did-fail-load", (_e, code, desc, url) => {
    writeStartupLog(`did-fail-load ${code} ${desc} ${url}`);
  });

  if (state.maximized) win.maximize();
  win.once("ready-to-show", () => win.show());
  let saveTimer = null;
  const queueSave = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveWindowState(win), 400);
  };
  win.on("resize", queueSave);
  win.on("move", queueSave);
  win.on("close", () => saveWindowState(win));
  mainWindow = win;
  return win;
}

// --- Instância única: evita dois processos gravando no mesmo banco ---
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

app.whenReady().then(() => {
  writeStartupLog("app ready, userData=" + app.getPath("userData"));
  try {
  const userData = ensureDirs();
  const db = initDb(path.join(userData, "tefilin.db"));
  dbRef = db;
  seedDefaults(db);
  rotateBackup(db, userData);
  syncEngineRef = registerIpc(ipcMain, db, userData);

  ipcMain.handle("sync:chooseFolder", async () => {
    try {
      const result = await dialog.showOpenDialog(mainWindow, {
        title: "Selecionar pasta do Google Drive para o Tefilin",
        properties: ["openDirectory", "createDirectory"],
      });
      if (result.canceled || !result.filePaths[0]) return { canceled: true };
      return { canceled: false, ...(syncEngineRef ? syncEngineRef.setFolder(result.filePaths[0]) : {}) };
    } catch (e) {
      return { canceled: false, error: String((e && e.message) || e) };
    }
  });

  // --- Exportar / Importar banco (.tefilin) ---
  const dbFile = path.join(userData, "tefilin.db");
  ipcMain.handle("dbfile:export", async () => {
    try {
      checkpoint(db);
      const stamp = new Date().toISOString().slice(0, 10);
      const res = await dialog.showSaveDialog(mainWindow, {
        title: "Exportar banco de dados",
        defaultPath: path.join(app.getPath("documents"), `tefilin-${stamp}.tefilin`),
        filters: [{ name: "Banco Tefilin", extensions: ["tefilin"] }],
      });
      if (res.canceled || !res.filePath) return { canceled: true };
      fs.copyFileSync(dbFile, res.filePath);
      return { canceled: false, path: res.filePath };
    } catch (e) {
      return { error: String((e && e.message) || e) };
    }
  });
  ipcMain.handle("dbfile:import", async () => {
    try {
      const res = await dialog.showOpenDialog(mainWindow, {
        title: "Importar banco de dados",
        properties: ["openFile"],
        filters: [{ name: "Banco Tefilin", extensions: ["tefilin", "db"] }],
      });
      if (res.canceled || !res.filePaths[0]) return { canceled: true };
      const src = res.filePaths[0];
      // valida se é um SQLite válido antes de substituir
      const head = Buffer.alloc(16);
      const fd = fs.openSync(src, "r");
      fs.readSync(fd, head, 0, 16, 0);
      fs.closeSync(fd);
      if (head.toString("utf8", 0, 15) !== "SQLite format 3") {
        return { error: "Arquivo inválido: não é um banco Tefilin." };
      }
      checkpoint(db);
      try { if (syncEngineRef) syncEngineRef.stop(); } catch (_) {}
      try { db.close(); } catch (_) {}
      dbRef = null;
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      fs.copyFileSync(dbFile, path.join(userData, "backups", `antes-import-${stamp}.db`));
      for (const suffix of ["-wal", "-shm"]) {
        try { fs.unlinkSync(dbFile + suffix); } catch (_) {}
      }
      fs.copyFileSync(src, dbFile);
      app.relaunch();
      app.exit(0);
      return { canceled: false, path: src };
    } catch (e) {
      return { error: String((e && e.message) || e) };
    }
  });

  // Protocolo customizado para servir arquivos de upload em <img src="tefilin-asset://bucket/path">
  protocol.registerFileProtocol("tefilin-asset", (request, callback) => {
    try {
      const url = decodeURIComponent(request.url.replace("tefilin-asset://", ""));
      const filePath = path.join(userData, "uploads", url);
      callback({ path: filePath });
    } catch (e) {
      callback({ error: -2 });
    }
  });

  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
  } catch (e) {
    writeStartupLog("startup error: " + (e && e.stack || e));
    throw e;
  }
}).catch((e) => {
  writeStartupLog("whenReady rejected: " + (e && e.stack || e));
});
}

// Fecha o banco com segurança ao sair (checkpoint do WAL)
app.on("before-quit", () => {
  try { if (syncEngineRef) syncEngineRef.stop(); } catch (_) {}
  if (dbRef) {
    checkpoint(dbRef);
    try { dbRef.close(); } catch (_) {}
    dbRef = null;
  }
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});