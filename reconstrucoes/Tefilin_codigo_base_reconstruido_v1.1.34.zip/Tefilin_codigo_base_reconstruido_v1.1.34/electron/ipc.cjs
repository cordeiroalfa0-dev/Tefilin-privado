const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const uuid = () => crypto.randomUUID();

// Cache de prepared statements
const stmtCache = new Map();
function prep(db, sql) {
  let s = stmtCache.get(sql);
  if (!s) {
    s = db.prepare(sql);
    if (stmtCache.size > 300) stmtCache.clear();
    stmtCache.set(sql, s);
  }
  return s;
}

function purgeExpiredSessions(db) {
  try {
    db.exec("DELETE FROM sessions WHERE expires_at <= datetime('now')");
  } catch (_) {}
}

function ensureAdmin(db, email, password, username) {
  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  const hash = bcrypt.hashSync(password, 10);
  if (exists) {
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, exists.id);
    return;
  }
  const id = uuid();
  db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
    id, email, hash, JSON.stringify({ username })
  );
  db.prepare("INSERT OR IGNORE INTO profiles(id,username,email) VALUES(?,?,?)").run(id, username, email);
  db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), id, "admin");
  console.log(`[seed] usuário admin ${email} criado/atualizado`);
}

const { seedSurprise } = require('./seed_surprise.cjs');
const { SyncEngine } = require("./sync-engine.cjs");

function seedDefaults(db) {
  const config = db.prepare("SELECT nome_igreja FROM configuracoes LIMIT 1").get();
  if (!config || config.nome_igreja !== 'Catedral da Esperança Internacional') {
    console.log("Forçando Seed Surpresa v1.1.35...");
    seedSurprise(db);
  } else {
    ensureAdmin(db, "apostolo@catedral.com", "admin123", "Apóstolo Gabriel");
    for(let i=1; i<=10; i++) {
      ensureAdmin(db, `pastor${i}@catedral.com`, "admin123", `Pastor Filial ${i}`);
    }
  }
  purgeExpiredSessions(db);
}

// Lógica de isolamento Multi-Igreja
function applyMultiChurchFilter(db, op, token) {
  if (!token) return;
  const session = db.prepare("SELECT user_id FROM sessions WHERE token = ? AND expires_at > datetime('now')").get(token);
  if (!session) return;

  const role = db.prepare("SELECT role FROM user_roles WHERE user_id = ?").get(session.user_id)?.role;
  if (role === 'admin') return; // Admin Full vê tudo

  const profile = db.prepare("SELECT igreja_id FROM profiles WHERE id = ?").get(session.user_id);
  if (profile && profile.igreja_id) {
    // Injetar filtro de igreja_id
    if (!op.filters) op.filters = [];
    op.filters.push({ op: 'eq', col: 'igreja_id', val: profile.igreja_id });
    
    // Para inserts, garantir que o dado pertença à igreja do usuário
    if (op.action === 'insert') {
      const values = Array.isArray(op.values) ? op.values : [op.values];
      values.forEach(v => v.igreja_id = profile.igreja_id);
    }
  }
}

function runQuery(db, op, token) {
  const { table, action } = op;
  
  // Aplicar isolamento se não for tabela de sistema
  const systemTables = ['users', 'profiles', 'user_roles', 'sessions', 'configuracoes', 'igrejas'];
  if (!systemTables.includes(table)) {
    applyMultiChurchFilter(db, op, token);
  }

  try {
    if (action === "select") {
      const where = buildWhere(op.filters);
      const orderBy = op.orderBy
        ? ` ORDER BY ${op.orderBy.column} ${op.orderBy.ascending === false ? "DESC" : "ASC"}`
        : "";
      const limit = op.limit ? ` LIMIT ${op.limit}` : "";
      const offset = op.range ? ` LIMIT ${op.range.to - op.range.from + 1} OFFSET ${op.range.from}` : "";
      const sql = `SELECT * FROM ${table}${where.sql}${orderBy}${offset || limit}`;
      let rows = prep(db, sql).all(...where.params);
      rows = applyEmbeds(db, table, rows, op.columns);
      rows = rows.map((r) => parseJsonFields(table, r));
      if (op.single || op.maybeSingle) {
        return { data: rows[0] ?? null, error: null };
      }
      return { data: rows, error: null };
    }
    if (action === "insert") {
      const values = Array.isArray(op.values) ? op.values : [op.values];
      const inserted = [];
      const stmt = (cols) =>
        prep(db,
          `${op.upsert ? "INSERT OR REPLACE" : "INSERT"} INTO ${table} (${cols.join(",")}) VALUES (${cols.map(() => "?").join(",")})`
        );
      const many = values.length > 1;
      if (many) db.exec("BEGIN");
      try {
        for (const v of values) {
          if (!v.id) v.id = uuid();
          const cleaned = serializeRow(v);
          const cols = Object.keys(cleaned);
          stmt(cols).run(...cols.map((c) => cleaned[c]));
          const row = prep(db, `SELECT * FROM ${table} WHERE id = ?`).get(v.id);
          inserted.push(parseJsonFields(table, row));
        }
        if (many) db.exec("COMMIT");
      } catch (e) {
        if (many) { try { db.exec("ROLLBACK"); } catch (_) {} }
        throw e;
      }
      if (op.returnSelect) {
        if (op.single) return { data: inserted[0] ?? null, error: null };
        return { data: inserted, error: null };
      }
      return { data: null, error: null };
    }
    if (action === "update") {
      const where = buildWhere(op.filters);
      const cleaned = serializeRow(op.updates);
      const cols = Object.keys(cleaned);
      if (cols.length === 0) return { data: null, error: null };
      const sql = `UPDATE ${table} SET ${cols.map((c) => `${c} = ?`).join(",")}${where.sql}`;
      prep(db, sql).run(...cols.map((c) => cleaned[c]), ...where.params);
      return { data: null, error: null };
    }
    if (action === "delete") {
      const where = buildWhere(op.filters);
      prep(db, `DELETE FROM ${table}${where.sql}`).run(...where.params);
      return { data: null, error: null };
    }
    return { data: null, error: { message: "unknown action " + action } };
  } catch (e) {
    console.error("[db error]", op, e);
    return { data: null, error: { message: e.message } };
  }
}

function buildWhere(filters = []) {
  if (!filters.length) return { sql: "", params: [] };
  const parts = [];
  const params = [];
  for (const f of filters) {
    if (f.op === "eq") { parts.push(`${f.col} = ?`); params.push(f.val); }
    else if (f.op === "neq") { parts.push(`${f.col} != ?`); params.push(f.val); }
    else if (f.op === "gt") { parts.push(`${f.col} > ?`); params.push(f.val); }
    else if (f.op === "gte") { parts.push(`${f.col} >= ?`); params.push(f.val); }
    else if (f.op === "lt") { parts.push(`${f.col} < ?`); params.push(f.val); }
    else if (f.op === "lte") { parts.push(`${f.col} <= ?`); params.push(f.val); }
    else if (f.op === "like" || f.op === "ilike") { parts.push(`${f.col} LIKE ?`); params.push(f.val); }
    else if (f.op === "in") {
      const arr = Array.isArray(f.val) ? f.val : [f.val];
      parts.push(`${f.col} IN (${arr.map(() => "?").join(",")})`);
      params.push(...arr);
    }
    else if (f.op === "is") {
      if (f.val === null) parts.push(`${f.col} IS NULL`);
      else { parts.push(`${f.col} = ?`); params.push(f.val); }
    }
  }
  return { sql: " WHERE " + parts.join(" AND "), params };
}

const JSON_FIELDS = { avisos: ["imagens"], users: ["raw_user_meta_data"] };
function parseJsonFields(table, row) {
  if (!row) return row;
  const fields = JSON_FIELDS[table] || [];
  for (const f of fields) {
    if (typeof row[f] === "string") {
      try { row[f] = JSON.parse(row[f]); } catch {}
    }
  }
  return row;
}
function serializeRow(row) {
  const out = { ...row };
  for (const k of Object.keys(out)) {
    if (out[k] && typeof out[k] === "object" && !(out[k] instanceof Date)) {
      out[k] = JSON.stringify(out[k]);
    } else if (out[k] instanceof Date) {
      out[k] = out[k].toISOString();
    } else if (typeof out[k] === "boolean") {
      out[k] = out[k] ? 1 : 0;
    }
  }
  return out;
}

function applyEmbeds(db, table, rows, columns) {
  if (!columns || !columns.includes("(")) return rows;
  const matches = [...columns.matchAll(/(\w+)\(([^)]+)\)/g)];
  for (const m of matches) {
    const relTable = m[1];
    const relCols = m[2].split(",").map((s) => s.trim());
    const fkCandidates = [relTable.replace(/s$/, "") + "_id", relTable + "_id"];
    let fk = null;
    if (rows[0]) {
      for (const c of fkCandidates) if (c in rows[0]) { fk = c; break; }
    }
    if (!fk) continue;
    const ids = [...new Set(rows.map((r) => r[fk]).filter(Boolean))];
    if (!ids.length) continue;
    const relRows = db
      .prepare(`SELECT id, ${relCols.join(",")} FROM ${relTable} WHERE id IN (${ids.map(() => "?").join(",")})`)
      .all(...ids);
    const map = new Map(relRows.map((r) => [r.id, r]));
    for (const r of rows) {
      r[relTable] = map.get(r[fk]) || null;
    }
  }
  return rows;
}

// ---------- Auth ----------
function authSignUp(db, { email, password, metadata }) {
  try {
    const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (exists) return { data: null, error: { message: "User already registered" } };
    const id = uuid();
    const hash = bcrypt.hashSync(password, 10);
    db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
      id, email, hash, JSON.stringify(metadata || {})
    );
    const username = (metadata && metadata.username) || email.split("@")[0];
    db.prepare("INSERT OR IGNORE INTO profiles(id,username,email) VALUES(?,?,?)").run(id, username, email);
    db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), id, "user");
    const token = createSession(db, id);
    return { data: { user: makeUser(id, email, metadata), session: { access_token: token, user: makeUser(id, email, metadata) } }, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message } };
  }
}
function authCreateUser(db, { email, password, metadata, role = "user" }) {
  try {
    const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (exists) return { data: null, error: { message: "User already registered" } };
    const id = uuid();
    const hash = bcrypt.hashSync(password, 10);
    db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
      id, email, hash, JSON.stringify(metadata || {})
    );
    const username = (metadata && metadata.username) || email.split("@")[0];
    const igreja_id = metadata?.igreja_id || null;
    db.prepare("INSERT OR IGNORE INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(id, username, email, igreja_id);
    db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), id, role);
    return { data: { user: makeUser(id, email, metadata) }, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message } };
  }
}
function authDeleteUser(db, userId) {
  try {
    db.prepare("DELETE FROM users WHERE id = ?").run(userId);
    return { error: null };
  } catch (e) {
    return { error: { message: e.message } };
  }
}
function authSignIn(db, { email, password }) {
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user) return { data: null, error: { message: "Invalid login credentials" } };
  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid) return { data: null, error: { message: "Invalid login credentials" } };
  if (!bcrypt.compareSync(password, user.password_hash))
    return { data: null, error: { message: "Invalid login credentials" } };
  const meta = JSON.parse(user.raw_user_meta_data || "{}");
  const token = createSession(db, user.id);
  return {
    data: { user: makeUser(user.id, user.email, meta), session: { access_token: token, user: makeUser(user.id, user.email, meta) } },
    error: null,
  };
}
function authSignOut(db, token) {
  db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
  return { error: null };
}
function authGetUser(db, token) {
  if (!token) return { data: { user: null }, error: null };
  const s = db.prepare("SELECT * FROM sessions WHERE token = ? AND expires_at > datetime('now')").get(token);
  if (!s) return { data: { user: null }, error: null };
  const u = db.prepare("SELECT * FROM users WHERE id = ?").get(s.user_id);
  if (!u) return { data: { user: null }, error: null };
  return { data: { user: makeUser(u.id, u.email, JSON.parse(u.raw_user_meta_data || "{}")) }, error: null };
}
function createSession(db, userId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();
  db.prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)").run(token, userId, expires);
  return token;
}
function makeUser(id, email, meta) {
  return { id, email, user_metadata: meta || {}, app_metadata: {}, aud: "authenticated", created_at: new Date().toISOString() };
}

// ---------- Storage (filesystem) ----------
function storageUpload(userData, { bucket, path: filePath, base64, contentType }) {
  const dir = path.join(userData, "uploads", bucket);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const fp = path.join(dir, filePath);
  fs.mkdirSync(path.dirname(fp), { recursive: true });
  fs.writeFileSync(fp, Buffer.from(base64, "base64"));
  return { data: { path: filePath }, error: null };
}
function storageRemove(userData, { bucket, paths }) {
  for (const p of paths) {
    try { fs.unlinkSync(path.join(userData, "uploads", bucket, p)); } catch {}
  }
  return { data: paths, error: null };
}
function storageDownload(userData, { bucket, path: filePath }) {
  try {
    const buf = fs.readFileSync(path.join(userData, "uploads", bucket, filePath));
    return { data: buf.toString("base64"), error: null };
  } catch (e) {
    return { data: null, error: { message: e.message } };
  }
}
function storagePublicUrl(userData, { bucket, path: filePath }) {
  return { data: { publicUrl: `tefilin-asset://${bucket}/${filePath}` } };
}
function storageList(userData, { bucket, path: folder = "" }) {
  try {
    const dir = path.join(userData, "uploads", bucket, folder);
    if (!fs.existsSync(dir)) return { data: [], error: null };
    const data = fs.readdirSync(dir).map((name) => {
      const st = fs.statSync(path.join(dir, name));
      return { name, created_at: st.birthtime.toISOString(), updated_at: st.mtime.toISOString(), metadata: { size: st.size } };
    });
    return { data, error: null };
  } catch (e) {
    return { data: null, error: { message: e.message } };
  }
}

function registerIpc(ipcMain, db, userData) {
  const syncEngine = new SyncEngine(db, userData);
  ipcMain.handle("db:query", (_e, op) => {
    const token = _e.sender.session?.token || null; // Simulação de token na sessão do renderer
    return runQuery(db, op, token);
  });
  ipcMain.handle("auth:signUp", (_e, p) => authSignUp(db, p));
  ipcMain.handle("auth:createUser", (_e, p) => authCreateUser(db, p));
  ipcMain.handle("auth:deleteUser", (_e, userId) => authDeleteUser(db, userId));
  ipcMain.handle("auth:signIn", (_e, p) => authSignIn(db, p));
  ipcMain.handle("auth:signOut", (_e, t) => authSignOut(db, t));
  ipcMain.handle("auth:getUser", (_e, t) => authGetUser(db, t));
  ipcMain.handle("storage:upload", (_e, p) => storageUpload(userData, p));
  ipcMain.handle("storage:remove", (_e, p) => storageRemove(userData, p));
  ipcMain.handle("storage:download", (_e, p) => storageDownload(userData, p));
  ipcMain.handle("storage:publicUrl", (_e, p) => storagePublicUrl(userData, p));
  ipcMain.handle("storage:list", (_e, p) => storageList(userData, p));
  ipcMain.handle("sync:status", () => syncEngine.status());
  ipcMain.handle("sync:configure", (_e, p) => syncEngine.configure(p));
  ipcMain.handle("sync:push", () => syncEngine.push());
  ipcMain.handle("sync:pull", () => syncEngine.pull());
  ipcMain.handle("sync:now", () => syncEngine.syncNow());
  ipcMain.handle("sync:stop", () => { syncEngine.stop(); return syncEngine.status(); });
  return syncEngine;
}

const { seedMassive } = require("./seed_massive.cjs");
module.exports = { registerIpc, seedDefaults, seedMassive };
