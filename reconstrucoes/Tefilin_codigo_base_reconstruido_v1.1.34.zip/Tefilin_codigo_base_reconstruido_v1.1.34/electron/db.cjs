const { DatabaseSync } = require("node:sqlite");
const fs = require("fs");
const path = require("path");

function runMigrations(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS _migrations (
    name TEXT PRIMARY KEY,
    applied_at TEXT DEFAULT (datetime('now'))
  )`);
  const dir = path.join(__dirname, "migrations");
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
  const applied = new Set(db.prepare("SELECT name FROM _migrations").all().map((r) => r.name));
  for (const f of files) {
    if (applied.has(f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), "utf8");
    db.exec("BEGIN");
    try {
      for (const stmt of sql.split(';').map((s) => s.trim()).filter(Boolean)) {
        try {
          db.exec(stmt);
        } catch (e) {
          if (!/duplicate column name/i.test(e.message)) throw e;
        }
      }
      db.prepare("INSERT INTO _migrations(name) VALUES(?)").run(f);
      db.exec("COMMIT");
      console.log("[migration]", f);
    } catch (e) {
      db.exec("ROLLBACK");
      console.error("[migration failed]", f, e);
      throw e;
    }
  }
}

function initDb(dbPath) {
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA synchronous = NORMAL");
  db.exec("PRAGMA busy_timeout = 5000");
  db.exec("PRAGMA temp_store = MEMORY");
  db.exec("PRAGMA cache_size = -20000");
  db.exec("PRAGMA foreign_keys = ON");
  runMigrations(db);
  try {
    const chk = db.prepare("PRAGMA integrity_check").get();
    const val = chk && (chk.integrity_check || Object.values(chk)[0]);
    if (val && val !== "ok") console.error("[db] integrity_check:", val);
  } catch (e) {
    console.error("[db] integrity_check falhou", e);
  }
  try {
    db.exec("ANALYZE");
  } catch (_) {}
  return db;
}

function checkpoint(db) {
  try { db.exec("PRAGMA wal_checkpoint(TRUNCATE)"); } catch (_) {}
}

module.exports = { initDb, checkpoint };