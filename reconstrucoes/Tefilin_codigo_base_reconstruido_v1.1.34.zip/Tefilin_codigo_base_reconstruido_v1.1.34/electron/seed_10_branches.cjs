const crypto = require("crypto");
const bcrypt = require("bcryptjs");

const uuid = () => crypto.randomUUID();

function seed10Branches(db) {
  console.log(">>> INICIANDO SEED COMPLETO: SEDE + 10 FILIAIS <<<");

  // Limpeza de tabelas principais
  const tables = [
    "mensagens_whatsapp", "visitas_pastorais", "dizimos", "ofertas", "avisos",
    "dizimistas", "visitantes", "templates_whatsapp", "cultos", "patrimonio",
    "cartas_recomendacao", "membros", "user_roles", "profiles", "sessions", "users", "configuracoes", "igrejas"
  ];
  db.exec("PRAGMA foreign_keys = OFF");
  tables.forEach(t => {
    try { db.exec(`DELETE FROM ${t}`); } catch(e) {}
  });
  db.exec("PRAGMA foreign_keys = ON");

  // 1. Criar Sede
  const sedeId = uuid();
  db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
    sedeId, 'Sede Mundial Avivamento Profético', 'Sede', 'Bispo Emerson', 'Av. das Nações Unidas, 888', 'Curitiba', 'PR'
  );

  // 2. Criar 10 Filiais
  const cidadesFiliais = [
    { nome: 'Avivamento - São Paulo (SP)', cidade: 'São Paulo', pastor: 'Pr. Carlos Silva' },
    { nome: 'Avivamento - Rio de Janeiro (RJ)', cidade: 'Rio de Janeiro', pastor: 'Pr. Roberto Santos' },
    { nome: 'Avivamento - Belo Horizonte (MG)', cidade: 'Belo Horizonte', pastor: 'Pr. Marcos Oliveira' },
    { nome: 'Avivamento - Salvador (BA)', cidade: 'Salvador', pastor: 'Pr. Antonio Souza' },
    { nome: 'Avivamento - Porto Alegre (RS)', cidade: 'Porto Alegre', pastor: 'Pr. Lucas Ferreira' },
    { nome: 'Avivamento - Brasília (DF)', cidade: 'Brasília', pastor: 'Pr. Paulo Mendes' },
    { nome: 'Avivamento - Fortaleza (CE)', cidade: 'Fortaleza', pastor: 'Pr. Francisco Lima' },
    { nome: 'Avivamento - Manaus (AM)', cidade: 'Manaus', pastor: 'Pr. Gabriel Costa' },
    { nome: 'Avivamento - Curitiba Norte (PR)', cidade: 'Curitiba', pastor: 'Pr. André Ribeiro' },
    { nome: 'Avivamento - Florianópolis (SC)', cidade: 'Florianópolis', pastor: 'Pr. Rafael Rocha' }
  ];

  const filialIds = [];
  cidadesFiliais.forEach(f => {
    const fId = uuid();
    filialIds.push(fId);
    db.prepare("INSERT INTO igrejas (id, nome, tipo, pastor_responsavel, endereco, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      fId, f.nome, 'Congregação', f.pastor, `Rua Principal, 100 - ${f.cidade}`, f.cidade, 'BR'
    );
  });

  const todasIgrejas = [sedeId, ...filialIds];

  // 3. Branding da Sede
  db.prepare("INSERT INTO configuracoes (id, nome_sistema, nome_igreja, versiculo, endereco, cor_primaria, cor_sidebar, cor_cards, cor_fundo, cor_texto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(
    'default',
    'Tefilin Pro',
    'Sede Mundial Avivamento Profético',
    'Pois eu sei os planos que tenho para vocês, diz o Senhor, planos de prosperidade e não de mal. (Jeremias 29:11)',
    'Av. das Nações Unidas, 888 - Centro, Curitiba/PR',
    '#7C3AED',
    '#0F172A',
    '#FFFFFF',
    '#F8FAFC',
    '#1E293B'
  );

  // 4. Usuários: Bispo (HQ) e Pastores de cada Filial
  const adminId = uuid();
  const hash = bcrypt.hashSync("admin123", 10);
  db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
    adminId, "bispo@avivamento.com", hash, JSON.stringify({ username: "Bispo Emerson" })
  );
  db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(adminId, "Bispo Emerson", "bispo@avivamento.com", sedeId);
  db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), adminId, "admin");

  // Criar login para cada filial (ex: filial1@avivamento.com até filial10@avivamento.com)
  filialIds.forEach((fId, index) => {
    const uId = uuid();
    const email = `filial${index + 1}@avivamento.com`;
    db.prepare("INSERT INTO users(id,email,password_hash,raw_user_meta_data) VALUES(?,?,?,?)").run(
      uId, email, hash, JSON.stringify({ username: `Pastor Filial ${index + 1}` })
    );
    db.prepare("INSERT INTO profiles(id,username,email,igreja_id) VALUES(?,?,?,?)").run(uId, `Pastor Filial ${index + 1}`, email, fId);
    db.prepare("INSERT INTO user_roles(id,user_id,role) VALUES(?,?,?)").run(uuid(), uId, "admin");
  });

  // 5. Gerar dados massivos distribuídos entre Sede e as 10 Filiais (150 membros, 150 dízimos, ofertas, etc.)
  const prenomes = ["José", "Maria", "João", "Ana", "Carlos", "Juliana", "Marcos", "Fernanda", "Lucas", "Beatriz"];
  const sobrenomes = ["Silva", "Santos", "Oliveira", "Souza", "Costa", "Carvalho", "Almeida", "Ferreira", "Ribeiro", "Mendes"];

  function gerarNome() {
    return prenomes[Math.floor(Math.random() * prenomes.length)] + " " + 
           sobrenomes[Math.floor(Math.random() * sobrenomes.length)] + " " + 
           sobrenomes[Math.floor(Math.random() * sobrenomes.length)];
  }

  // Membros
  const stmtMembro = db.prepare("INSERT INTO membros (id, nome_completo, status, cargo, congregacao, eh_dizimista, igreja_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
  for (let i = 0; i < 200; i++) {
    const id = uuid();
    const igrejaId = todasIgrejas[i % todasIgrejas.length];
    stmtMembro.run(id, gerarNome(), 'ativo', i < 11 ? 'Pastor' : 'Membro', 'Templo Central', 1, igrejaId);
  }

  // Dízimos e Ofertas
  const stmtDizimista = db.prepare("INSERT INTO dizimistas (id, nome_completo, telefone, igreja_id) VALUES (?, ?, ?, ?)");
  const stmtDizimo = db.prepare("INSERT INTO dizimos (id, dizimista_id, valor, data, forma_pagamento, igreja_id) VALUES (?, ?, ?, ?, ?, ?)");
  const stmtOferta = db.prepare("INSERT INTO ofertas (id, valor, data, tipo, igreja_id) VALUES (?, ?, ?, ?, ?)");

  const membros = db.prepare("SELECT id, nome_completo, igreja_id FROM membros").all();
  membros.forEach((m, i) => {
    const dId = uuid();
    stmtDizimista.run(dId, m.nome_completo, '(41) 99999-0000', m.igreja_id);
    stmtDizimo.run(uuid(), dId, 300 + Math.random() * 1500, '2026-08-' + ((i % 20) + 1).toString().padStart(2, '0'), 'PIX', m.igreja_id);
    stmtOferta.run(uuid(), 100 + Math.random() * 800, '2026-08-' + ((i % 20) + 1).toString().padStart(2, '0'), 'Culto de Domingo', m.igreja_id);
  });

  console.log(">>> SEED SEDE + 10 FILIAIS CONCLUÍDO COM SUCESSO! <<<");
}

module.exports = { seed10Branches };
